#import <Foundation/Foundation.h>
#import "CleverTap.h"
@class CleverTapDisplayUnitContent;
@protocol CleverTapDisplayUnitCache;

/*!
 
 @abstract
 The `CleverTapDisplayUnit` represents the display unit object.
 */
@interface CleverTapDisplayUnit : NSObject

- (instancetype _Nullable )initWithJSON:(NSDictionary *_Nullable)json;
/*!
 * json defines the display unit data in the form of NSDictionary.
 */
@property (nullable, nonatomic, copy, readonly) NSDictionary *json;
/*!
 * unitID defines the display unit identifier.
 */
@property (nullable, nonatomic, copy, readonly) NSString *unitID;
/*!
 * type defines the display unit type.
 */
@property (nullable, nonatomic, copy, readonly) NSString *type;
/*!
 * bgColor defines the backgroundColor of the display unit.
 */
@property (nullable, nonatomic, copy, readonly) NSString *bgColor;
/*!
 * customExtras defines the extra data in the form of an NSDictionary. The extra key/value pairs set in the CleverTap dashboard.
 */
@property (nullable, nonatomic, copy, readonly) NSDictionary *customExtras;
/*!
 * content defines the content of the display unit.
 */
@property (nullable, nonatomic, copy, readonly) NSArray<CleverTapDisplayUnitContent *> *contents;

/*!
 @method metaDataForContentAtIndex:
 @abstract Returns wzrk_* metadata for a content item.

 Includes the wzrk_element_id, wzrk_index, wzrk_c2a, and wzrk_action / wzrk_data when applicable.
 Returns an empty dictionary for an invalid index or when no item attribution is available.
 
 @param contentIndex Zero-based index into contents.
 */
- (NSDictionary<NSString *, id> *_Nonnull)metaDataForContentAtIndex:(NSInteger)contentIndex
NS_SWIFT_NAME(metaData(forContentAt:));

@end

/*!
 
 @abstract
 The `CleverTapDisplayUnitContent` represents the display unit content.
 */
@interface CleverTapDisplayUnitContent : NSObject
/*!
 * title  defines the title section of the display unit content.
 */
@property (nullable, nonatomic, copy, readonly) NSString *title;
/*!
 * titleColor defines hex-code value of the title color as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *titleColor;
/*!
 * message  defines the message section of the display unit content.
 */
@property (nullable, nonatomic, copy, readonly) NSString *message;
/*!
 * messageColor defines hex-code value of the message color as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *messageColor;
/*!
 * videoPosterUrl defines video URL of the display unit as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *videoPosterUrl;
/*!
 * actionUrl defines action URL of the display unit as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *actionUrl;
/*!
 * mediaUrl defines media URL of the display unit as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *mediaUrl;
/*!
 * iconUrl defines icon URL of the display unit as String.
 */
@property (nullable, nonatomic, copy, readonly) NSString *iconUrl;
/*!
 * mediaIsAudio check whether mediaUrl is an audio.
 */
@property (nonatomic, readonly, assign) BOOL mediaIsAudio;
/*!
 * mediaIsVideo check whether mediaUrl is a video.
 */
@property (nonatomic, readonly, assign) BOOL mediaIsVideo;
/*!
 * mediaIsImage check whether mediaUrl is an image.
 */
@property (nonatomic, readonly, assign) BOOL mediaIsImage;
/*!
 * mediaIsGif check whether mediaUrl is a gif.
 */
@property (nonatomic, readonly, assign) BOOL mediaIsGif;
/*!
 * metaData contains this item's wzrk_* attribution, including server-provided
 * metadata and SDK-derived iOS action/data. Returns nil when no metadata is available.
 */
@property (nullable, nonatomic, copy, readonly) NSDictionary<NSString *, id> *metaData;

- (instancetype _Nullable )initWithJSON:(NSDictionary *_Nullable)jsonObject;

@end

@protocol CleverTapDisplayUnitDelegate <NSObject>
@optional
- (void)displayUnitsUpdated:(NSArray<CleverTapDisplayUnit *>*_Nonnull)displayUnits;
@end

typedef void (^CleverTapDisplayUnitSuccessBlock)(BOOL success);

@interface CleverTap (DisplayUnit)

/*!
 @method

 @abstract
 This method returns all the display units.

 @return all units currently held, or @c nil if no cache has been installed
 yet or the cache holds no units.
 */
- (NSArray<CleverTapDisplayUnit *>*_Nullable)getAllDisplayUnits;

/*!
 @method
 
 @abstract
 This method return display unit for the provided unitID
 */
- (CleverTapDisplayUnit *_Nullable)getDisplayUnitForID:(NSString *_Nonnull)unitID;

/*!
 @method
 
 @abstract
 The `CleverTapDisplayUnitDelegate` protocol provides methods for notifying
 your application (the adopting delegate) about display units.
 
 @discussion
 This sets the CleverTapDisplayUnitDelegate.
 
 @param delegate     an object conforming to the CleverTapDisplayUnitDelegate Protocol
 */
- (void)setDisplayUnitDelegate:(id <CleverTapDisplayUnitDelegate>_Nonnull)delegate;

/*!
 @method
 
 @abstract
 Record Notification Viewed for display unit.

 @discussion
 Call this every time your app shows a display unit. The SDK does not draw display units, so this
 call is the only way it can know that one was shown.

 Frequency caps need it. A campaign capped at three views a day is only held back after the SDK has
 been told about those three views. If the call is missing, the cap never applies and the view counts
 sent to CleverTap stay at zero.

 Call it once per view. Every call counts as another view, so do not call it from somewhere that runs
 more than once for a single display, such as a table or collection view cell being reused.

 @param unitID      unique id of the display unit
 */
- (void)recordDisplayUnitViewedEventForID:(NSString *_Nonnull)unitID;

/*!
 @method

 @abstract
 Record Notification Clicked for display unit.

 @param unitID       unique id of the display unit
 */
- (void)recordDisplayUnitClickedEventForID:(NSString *_Nonnull)unitID;

/*!
 @method recordDisplayUnitElementClickedEventForID:additionalProperties:

 @abstract Element-level click attribution for Native Display units.

 Element-level analog of @c -recordDisplayUnitClickedEventForID: — for Native
 Display units that host multiple interactive child elements (buttons,
 images, etc.), this method records which child element was clicked
 alongside the existing @c wzrk_* campaign attribution.

 @c evtData is assembled in two layers (later layers win on key collision):
 1. Caller's @c additionalProperties, merged verbatim — should include
    @c wzrk_element_id and other @c wzrk_* attribution fields injected by
    the BE into the action's @c metadata object.
 2. Cached unit's @c wzrk_* fields layered on top — so server-controlled
    attribution always wins over same-named caller-supplied keys.

 @param unitID                  the unitID of the Display Unit.
 @param additionalProperties    optional per-click context (action url,
                                custom KVs, …).
 */
- (void)recordDisplayUnitElementClickedEventForID:(NSString *_Nonnull)unitID
                             additionalProperties:(nullable NSDictionary<NSString *, id> *)additionalProperties;

/*!
 @method recordDisplayUnitElementViewedEventForID:additionalProperties:

 @abstract Element-level view attribution for Native Display units.

 Raises the Notification Viewed event for a single child element of a Native Display
 unit (e.g. one carousel slide coming on screen) instead of the whole unit.

 @c evtData is assembled in two layers (later layers win on key collision):
 1. Caller's @c additionalProperties, merged verbatim — should include
    @c wzrk_element_id and other @c wzrk_* attribution fields injected by
    the BE into the action's @c metadata object.
 2. Cached unit's @c wzrk_* fields layered on top — so server-controlled
    attribution always wins over same-named caller-supplied keys.

 @param unitID                  the unitID of the Display Unit.
 @param additionalProperties    optional per-element context (slide
                                attribution, custom KVs, …).
 */
- (void)recordDisplayUnitElementViewedEventForID:(NSString *_Nonnull)unitID
                            additionalProperties:(nullable NSDictionary<NSString *, id> *)additionalProperties;

/*!
 @method

 @abstract
 Replaces the SDK's display-unit cache with the supplied implementation.
 Pass `nil` to clear the reference (subsequent server responses will lazily
 install a fresh default cache).

 The new instance receives subsequent `updateDisplayUnits:` calls (e.g. from
 server responses) and serves all lookup sites: `getAllDisplayUnits`,
 `getDisplayUnitForID:`, `recordDisplayUnitViewedEventForID:`, and
 `recordDisplayUnitClickedEventForID:`.

 Implementations must be thread-safe. The display-unit delegate registered
 via `-setDisplayUnitDelegate:` fires only for server-pipeline activity —
 replacing the cache or mutating its contents from outside the SDK does not
 synthesise a delegate fire.

 @since 7.x.0
 */
- (void)setDisplayUnitCache:(nullable id<CleverTapDisplayUnitCache>)cache;

/*!
 @method

 @abstract
 Asks CleverTap for a fresh set of Native Display frequency cap rules.

 @discussion
 The SDK is given these rules when the app launches. Call this to ask for them again in the middle
 of a session. The rules that arrive replace the ones the SDK already holds.

 The rules do not arrive straight away. They come back on a later response from CleverTap. Any
 display unit delivered before then is checked against the rules the SDK holds at that moment.

 This call does nothing on an analytics only instance. It also does nothing inside an app extension.
 Neither one shows display units.
 */
- (void)fetchNativeDisplayMeta;

@end
