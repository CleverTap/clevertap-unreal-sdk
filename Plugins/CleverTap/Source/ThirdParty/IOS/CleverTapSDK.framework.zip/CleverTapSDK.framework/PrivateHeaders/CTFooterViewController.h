
#import "CTBaseHeaderFooterViewController.h"

@interface CTFooterViewController : CTBaseHeaderFooterViewController

@end
