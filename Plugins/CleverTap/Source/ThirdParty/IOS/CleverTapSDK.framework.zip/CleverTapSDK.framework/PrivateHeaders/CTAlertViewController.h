#import "CTInAppDisplayViewController.h"

@interface CTAlertViewController : CTInAppDisplayViewController

@end
