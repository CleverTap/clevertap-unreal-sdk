#import <Foundation/Foundation.h>
#if __has_include(<CleverTapSDK/CleverTapInstanceConfig.h>)
#import <CleverTapSDK/CleverTapInstanceConfig.h>
#else
#import "CleverTapInstanceConfig.h"
#endif

@interface CTPreferences : NSObject

+ (long)getIntForKey:(NSString *_Nonnull)key withResetValue:(long)resetValue;

+ (void)putInt:(long)resetValue forKey:(NSString *_Nonnull)key;

+ (NSString *_Nullable)getStringForKey:(NSString *_Nonnull)key withResetValue:(NSString *_Nullable)resetValue;

+ (void)putString:(NSString *_Nonnull)resetValue forKey:(NSString *_Nonnull)key;

// Returns nil when the key was never written. NSUserDefaults is read straight through.
+ (id _Nullable)getObjectForKey:(NSString *_Nonnull)key;

+ (void)putObject:(id _Nonnull)object forKey:(NSString *_Nonnull)key;

+ (void)removeObjectForKey:(NSString *_Nonnull)key;

+ (id _Nullable)unarchiveFromFile:(NSString *_Nonnull)filename ofType:(Class _Nonnull)cls  removeFile:(BOOL)remove;

+ (id _Nullable)unarchiveFromFile:(NSString *_Nonnull)filename ofTypes:(nonnull NSSet<Class> *)classes removeFile:(BOOL)remove;

+ (BOOL)archiveObject:(id _Nonnull)object forFileName:(NSString *_Nonnull)fileName config: (CleverTapInstanceConfig *_Nonnull)config;

+ (NSString *_Nonnull)storageKeyWithSuffix: (NSString *_Nonnull)suffix config: (CleverTapInstanceConfig *_Nonnull)config;

+ (NSString *_Nonnull)filePathfromFileName:(NSString *_Nonnull)filename;

@end
