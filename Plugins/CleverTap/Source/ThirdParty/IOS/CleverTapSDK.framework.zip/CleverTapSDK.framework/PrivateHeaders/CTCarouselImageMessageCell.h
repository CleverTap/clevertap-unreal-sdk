#import "CTCarouselMessageCell.h"

@interface CTCarouselImageMessageCell : CTCarouselMessageCell

@end
