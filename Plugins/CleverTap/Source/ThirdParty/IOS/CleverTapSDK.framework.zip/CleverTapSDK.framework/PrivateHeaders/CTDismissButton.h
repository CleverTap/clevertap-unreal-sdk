
#import <UIKit/UIKit.h>

@interface CTDismissButton : UIButton

@end
