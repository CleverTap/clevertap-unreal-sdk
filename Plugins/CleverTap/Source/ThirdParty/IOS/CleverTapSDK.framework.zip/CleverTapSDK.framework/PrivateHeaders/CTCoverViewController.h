#import "CTInAppDisplayViewController.h"

@interface CTCoverViewController : CTInAppDisplayViewController

@end
