#import "CTInboxBaseMessageCell.h"

@class SDAnimatedImageView;

@interface CTInboxSimpleMessageCell : CTInboxBaseMessageCell

@end
