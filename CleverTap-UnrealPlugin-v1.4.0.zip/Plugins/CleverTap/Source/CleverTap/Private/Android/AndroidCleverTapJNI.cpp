// Copyright CleverTap All Rights Reserved.
#include "Android/AndroidCleverTapJNI.h"
#include "Dom/JsonObject.h"
#include "Dom/JsonValue.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

#include "Android/AndroidJNIUtilities.h"
#include "Android/AndroidCleverTapPropertiesJNI.h"

#include "CleverTapLog.h"
#include "CleverTapLogLevel.h"
#include "CleverTapUtilities.h"

#include "Android/AndroidApplication.h"

namespace CleverTapSDK { namespace Android { namespace JNI {

jclass GetCleverTapAPIClass(JNIEnv* Env)
{
	static jclass CleverTapAPIClass = CacheClass(Env, "com.clevertap.android.sdk.CleverTapAPI");
	return CleverTapAPIClass;
}

static void SetIdentityKeys(JNIEnv* Env, jobject ConfigInstance, const TArray<FString>& IdentityKeys)
{
	static jclass StringClass = CacheClass(Env, "java/lang/String");
	if (!StringClass)
	{
		return;
	}

	jclass ConfigClass = Env->GetObjectClass(ConfigInstance);
	if (HandleExceptionOrError(Env, !ConfigClass, TEXT("Getting CleverTapInstanceConfig class")))
	{
		return;
	}
	jmethodID SetKeysMethod = GetMethodID(Env, ConfigClass, "setIdentityKeys", "([Ljava/lang/String;)V");
	if (!SetKeysMethod)
	{
		return;
	}

	jobjectArray KeyArray = Env->NewObjectArray(IdentityKeys.Num(), StringClass, nullptr);
	if (HandleException(Env, TEXT("Creating String Array")))
	{
		return;
	}
	for (int32 i = 0; i < IdentityKeys.Num(); ++i)
	{
		jstring JKey = Env->NewStringUTF(TCHAR_TO_UTF8(*IdentityKeys[i]));
		if (HandleException(Env, TEXT("Creating String")))
		{
			return;
		}
		Env->SetObjectArrayElement(KeyArray, i, JKey);
		if (HandleException(Env, TEXT("Setting String array element")))
		{
			return;
		}
		Env->DeleteLocalRef(JKey);
	}
	Env->CallVoidMethod(ConfigInstance, SetKeysMethod, KeyArray);
	HandleException(Env, TEXT("CleverTapInstanceConfig.setIdentityKeys()"));
	Env->DeleteLocalRef(KeyArray);
}

static jobject JavaEncryptionLevelFromString(JNIEnv* Env, const char* LevelName)
{
	static jclass EncryptionLevelClass = CacheClass(Env, "com/clevertap/android/sdk/cryption/EncryptionLevel");
	static jmethodID ValueOfMethod = GetStaticMethodID(Env, EncryptionLevelClass, "valueOf",
		"(Ljava/lang/String;)Lcom/clevertap/android/sdk/cryption/EncryptionLevel;");
	if (!ValueOfMethod)
	{
		return nullptr;
	}
	// Get the enum constant from the name
	jstring JavaLevelName = Env->NewStringUTF(LevelName);
	jobject LevelEnumValue = Env->CallStaticObjectMethod(EncryptionLevelClass, ValueOfMethod, JavaLevelName);
	if (ExceptionThrown(Env) || !LevelEnumValue)
	{
		HandleExceptionOrError(
			Env, !LevelEnumValue, FString::Printf(TEXT("Failed to get EncryptionLevel enum for: %s"), *LevelName));
		LevelEnumValue = nullptr;
		// fall through
	}
	Env->DeleteLocalRef(JavaLevelName);
	return LevelEnumValue;
}

/** returns the Java string for the corresponding enum value, so we can ask java for its value */
static const char* CleverTapEncryptionLevelJavaName(ECleverTapEncryptionLevel Level)
{
	switch (Level)
	{
		case ECleverTapEncryptionLevel::None:
			return "NONE";
		case ECleverTapEncryptionLevel::Medium:
			return "MEDIUM";
		default:
		{
			UE_LOG(LogCleverTap, Error,
				TEXT("Unhandled ECleverTapEncryptionLevel value. Defaulting to ECleverTapEncryptionLevel::None"));
			return "NONE";
		}
	}
}

static jobject CleverTapEncryptionLevelToJava(JNIEnv* Env, ECleverTapEncryptionLevel EncryptionLevel)
{
	return JavaEncryptionLevelFromString(Env, CleverTapEncryptionLevelJavaName(EncryptionLevel));
}

/** Returns the name of each ECleverTapLogLevel value in the Java code.
 *  These need to match the java spelling for the JNI integration to work!
 */
const char* CleverTapLogLevelJavaName(ECleverTapLogLevel LogLevel)
{
	switch (LogLevel)
	{
		case ECleverTapLogLevel::Off:
			return "OFF";
		case ECleverTapLogLevel::Info:
			return "INFO";
		case ECleverTapLogLevel::Debug:
			return "DEBUG";
		case ECleverTapLogLevel::Verbose:
			return "VERBOSE";
		default:
		{
			UE_LOG(LogCleverTap, Warning,
				TEXT("Unhandled ECleverTapLogLevel value. Defaulting to ECleverTapLogLevel::Off"));
			return "OFF";
		}
	}
}

static jobject CleverTapLogLevelToJava(JNIEnv* Env, ECleverTapLogLevel LogLevel)
{
	static jclass LogLevelClass = CacheClass(Env, "com/clevertap/android/sdk/CleverTapAPI$LogLevel");
	static jmethodID ValueOfMethod = GetStaticMethodID(
		Env, LogLevelClass, "valueOf", "(Ljava/lang/String;)Lcom/clevertap/android/sdk/CleverTapAPI$LogLevel;");
	if (!ValueOfMethod)
	{
		return nullptr;
	}
	jstring JavaLevelName = Env->NewStringUTF(CleverTapLogLevelJavaName(LogLevel));
	jobject LogLevelEnumValue = Env->CallStaticObjectMethod(LogLevelClass, ValueOfMethod, JavaLevelName);
	if (ExceptionThrown(Env) || !LogLevelEnumValue)
	{
		HandleExceptionOrError(Env, !LogLevelEnumValue,
			FString::Printf(TEXT("Failed to get LogLevel enum for: %s"), *CleverTapLogLevelJavaName(LogLevel)));
		LogLevelEnumValue = nullptr;
		// fall through
	}
	Env->DeleteLocalRef(JavaLevelName);
	return LogLevelEnumValue;
}

static int CleverTapLogLevelToJavaInt(JNIEnv* Env, ECleverTapLogLevel Level)
{
	static jclass LogLevelClass = CacheClass(Env, "com/clevertap/android/sdk/CleverTapAPI$LogLevel");
	static jmethodID OrdinalMethod = Env->GetMethodID(LogLevelClass, "ordinal", "()I");

	jobject EnumObject = CleverTapLogLevelToJava(Env, Level);
	if (!EnumObject)
	{
		return 0;
	}
	jint Ordinal = Env->CallIntMethod(EnumObject, OrdinalMethod);
	if (HandleException(Env, "LogLevel.ordinal()"))
	{
		// fall through
	}
	Env->DeleteLocalRef(EnumObject);
	return Ordinal;
}

static jobject CreateCleverTapInstanceConfig(JNIEnv* Env, const FCleverTapInstanceConfig& Config)
{
	static jclass ConfigClass = CacheClass(Env, "com/clevertap/android/sdk/CleverTapInstanceConfig");
	static jmethodID CreateMethod = GetStaticMethodID(Env, ConfigClass, "createInstance",
		"(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/clevertap/android/sdk/CleverTapInstanceConfig;");
	static jmethodID SetEncryptionMethod =
		GetMethodID(Env, ConfigClass, "setEncryptionLevel", "(Lcom/clevertap/android/sdk/cryption/EncryptionLevel;)V");
	static jmethodID SetDebugLevelMethod = GetMethodID(Env, ConfigClass, "setDebugLevel", "(I)V");
	if (!CreateMethod || !SetEncryptionMethod || !SetDebugLevelMethod)
	{
		return nullptr;
	}
	jobject Context = FAndroidApplication::GetGameActivityThis();

	// Convert FString parameters to Java Strings
	jstring JAccountId = Env->NewStringUTF(TCHAR_TO_UTF8(*Config.ProjectId));
	jstring JAccountToken = Env->NewStringUTF(TCHAR_TO_UTF8(*Config.ProjectToken));
	jstring JAccountRegion = Env->NewStringUTF(TCHAR_TO_UTF8(*Config.RegionCode));

	// Call createInstance and get the resulting object
	jobject ConfigInstance =
		Env->CallStaticObjectMethod(ConfigClass, CreateMethod, Context, JAccountId, JAccountToken, JAccountRegion);
	if (HandleExceptionOrError(Env, !ConfigInstance, TEXT("CleverTapInstanceConfig.createInstance() failed!")))
	{
		// keep going
	}
	Env->DeleteLocalRef(JAccountId);
	Env->DeleteLocalRef(JAccountToken);
	Env->DeleteLocalRef(JAccountRegion);
	if (!ConfigInstance)
	{
		return nullptr;
	}

	// install the identity keys
	SetIdentityKeys(Env, ConfigInstance, Config.GetIdentityKeys());

	// set the encryption level
	jobject JavaEncryption = CleverTapEncryptionLevelToJava(Env, Config.EncryptionLevel);
	Env->CallVoidMethod(ConfigInstance, SetEncryptionMethod, JavaEncryption);
	HandleException(Env, TEXT("CleverTapInstanceConfig.setEncryptionLevel() failed!"));
	Env->DeleteLocalRef(JavaEncryption);

	// set the log level; this version needs the java-side int value instead of the enum
	int JavaLevelInt = CleverTapLogLevelToJavaInt(Env, Config.LogLevel);
	Env->CallVoidMethod(ConfigInstance, SetDebugLevelMethod, JavaLevelInt);
	HandleException(Env, TEXT("CleverTapInstanceConfig.setDebugLevel() failed!"));

	return ConfigInstance;
}

static void SetDefaultConfig(JNIEnv* Env, jobject ConfigInstance)
{
	// Find the CleverTapAPI class
	static jclass CleverTapClass = GetCleverTapAPIClass(Env);
	static jfieldID DefaultConfigField =
		GetStaticFieldID(Env, CleverTapClass, "defaultConfig", "Lcom/clevertap/android/sdk/CleverTapInstanceConfig;");
	if (!DefaultConfigField)
	{
		return;
	}

	// Set the static field CleverTapAPI.defaultConfig = ConfigInstance;
	Env->SetStaticObjectField(CleverTapClass, DefaultConfigField, ConfigInstance);
	if (HandleException(Env, TEXT("Failed to set CleverTapAPI.defaultConfig")))
	{
		// error logged; fall through
	}
}

void SetDefaultConfig(JNIEnv* Env, const FCleverTapInstanceConfig& Config)
{
	jobject JavaConfig = CreateCleverTapInstanceConfig(Env, Config);
	if (!JavaConfig)
	{
		return;
	}
	SetDefaultConfig(Env, JavaConfig);
	Env->DeleteLocalRef(JavaConfig);
}

jobject GetDefaultInstance(JNIEnv* Env)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID GetInstanceMethod = GetStaticMethodID(Env, CleverTapAPIClass, "getDefaultInstance",
		"(Landroid/content/Context;)Lcom/clevertap/android/sdk/CleverTapAPI;");
	if (!GetInstanceMethod)
	{
		return nullptr;
	}

	jobject Activity = FAndroidApplication::GetGameActivityThis();
	jobject CleverTapInstance = Env->CallStaticObjectMethod(CleverTapAPIClass, GetInstanceMethod, Activity);
	if (HandleExceptionOrError(Env, !CleverTapInstance, TEXT("CleverTapAPI.getDefaultInstance() failed")))
	{
		return nullptr;
	}
	return CleverTapInstance;
}

jobject GetDefaultInstance(JNIEnv* Env, const FString& CleverTapId)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID GetInstanceMethod = GetStaticMethodID(Env, CleverTapAPIClass, "getDefaultInstance",
		"(Landroid/content/Context;Ljava/lang/String;)Lcom/clevertap/android/sdk/CleverTapAPI;");
	if (!GetInstanceMethod)
	{
		return nullptr;
	}
	jstring JCleverTapId = Env->NewStringUTF(TCHAR_TO_UTF8(*CleverTapId));
	jobject Activity = FAndroidApplication::GetGameActivityThis();
	jobject CleverTapInstance =
		Env->CallStaticObjectMethod(CleverTapAPIClass, GetInstanceMethod, Activity, JCleverTapId);
	if (HandleExceptionOrError(
			Env, !CleverTapInstance, TEXT("CleverTapAPI.getDefaultInstance(context,cleverTapId) failed")))
	{
		CleverTapInstance = nullptr;
	}
	Env->DeleteLocalRef(JCleverTapId);
	return CleverTapInstance;
}

bool SetDebugLevel(JNIEnv* Env, ECleverTapLogLevel Level)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetDebugLogLevelMethod = GetStaticMethodID(
		Env, CleverTapAPIClass, "setDebugLevel", "(Lcom/clevertap/android/sdk/CleverTapAPI$LogLevel;)V");
	if (!SetDebugLogLevelMethod)
	{
		return false;
	}

	jobject JavaLogLevel = CleverTapLogLevelToJava(Env, Level);
	if (!JavaLogLevel)
	{
		return false;
	}

	Env->CallStaticVoidMethod(CleverTapAPIClass, SetDebugLogLevelMethod, JavaLogLevel);
	bool bFailed = HandleException(Env, TEXT("setDebugLevel"));
	Env->DeleteLocalRef(JavaLogLevel);
	return bFailed;
}

bool LocalizeNotificationChannel(
	JNIEnv* Env, const FString& ChannelId, const FText& ChannelName, const FText& Description)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID LocalizeChannelMethod = GetStaticMethodID(Env, BridgeClass, "localizeNotificationChannel",
		"(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z");
	if (!LocalizeChannelMethod)
	{
		return false;
	}

	jobject Context = FAndroidApplication::GetGameActivityThis();
	jstring JChannelId = Env->NewStringUTF(TCHAR_TO_UTF8(*ChannelId));
	jstring JChannelName = Env->NewStringUTF(TCHAR_TO_UTF8(*ChannelName.ToString()));
	jstring JDescription = Env->NewStringUTF(TCHAR_TO_UTF8(*Description.ToString()));
	bool Success = Env->CallStaticBooleanMethod(
		BridgeClass, LocalizeChannelMethod, Context, JChannelId, JChannelName, JDescription);
	if (HandleException(Env, "localizeNotificationChannel()"))
	{
		Success = false;
	}
	Env->DeleteLocalRef(JChannelId);
	Env->DeleteLocalRef(JChannelName);
	Env->DeleteLocalRef(JDescription);
	return Success;
}

bool LocalizeNotificationChannelGroup(JNIEnv* Env, const FString& GroupId, const FText& GroupName)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID LocalizeGroupMethod = GetStaticMethodID(Env, BridgeClass, "localizeNotificationChannelGroup",
		"(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z");
	if (!LocalizeGroupMethod)
	{
		return false;
	}

	jobject Context = FAndroidApplication::GetGameActivityThis();
	jstring JGroupId = Env->NewStringUTF(TCHAR_TO_UTF8(*GroupId));
	jstring JGroupName = Env->NewStringUTF(TCHAR_TO_UTF8(*GroupName.ToString()));
	bool Success = Env->CallStaticBooleanMethod(BridgeClass, LocalizeGroupMethod, Context, JGroupId, JGroupName);
	if (HandleException(Env, "localizeNotificationChannelGroup()"))
	{
		Success = false;
	}
	Env->DeleteLocalRef(JGroupId);
	Env->DeleteLocalRef(JGroupName);
	return Success;
}

jobject CreateUECleverTapListener(JNIEnv* Env, jobject CleverTapInstance, void* NativeInstance)
{
	static const char* ClassPath = "com/clevertap/android/unreal/UECleverTapListener";
	static jclass ListenerClass = CacheClass(Env, ClassPath);
	static jmethodID ListenerConstructor = GetMethodID(Env, ListenerClass, "<init>", "(J)V");
	if (!ListenerConstructor)
	{
		return nullptr;
	}
	jobject Listener = Env->NewObject(ListenerClass, ListenerConstructor, jlong(NativeInstance));
	if (HandleExceptionOrError(Env, !Listener, "Creating Listener"))
	{
		UE_LOG(LogCleverTap, Error, TEXT("Failed creating listener of class \"%hs\""), ClassPath);
		Listener = nullptr;
	}
	return Listener;
}

void RegisterPushPermissionResponseListener(JNIEnv* Env, jobject CleverTapInstance, jobject ListenerInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID RegisterListenerMethod =
		GetMethodID(Env, CleverTapAPIClass, "registerPushPermissionNotificationResponseListener",
			"(Lcom/clevertap/android/sdk/PushPermissionResponseListener;)V");
	if (!RegisterListenerMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, RegisterListenerMethod, ListenerInstance);
	HandleException(Env, "registerPushPermissionNotificationResponseListener()");
}

void SetPushNotificationClickedListener(JNIEnv* Env, jobject CleverTapInstance, jobject ListenerInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetListenerMethod = GetMethodID(Env, CleverTapAPIClass, "setCTPushNotificationListener",
		"(Lcom/clevertap/android/sdk/pushnotification/CTPushNotificationListener;)V");
	if (!SetListenerMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, SetListenerMethod, ListenerInstance);
	HandleException(Env, "setCTPushNotificationListener()");
}

void SetInAppNotificationListener(JNIEnv* Env, jobject CleverTapInstance, jobject ListenerInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetListenerMethod = GetMethodID(Env, CleverTapAPIClass, "setInAppNotificationListener",
		"(Lcom/clevertap/android/sdk/InAppNotificationListener;)V");
	if (!SetListenerMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, SetListenerMethod, ListenerInstance);
	HandleException(Env, "setInAppNotificationListener()");
}

void SetInAppNotificationButtonListener(JNIEnv* Env, jobject CleverTapInstance, jobject ListenerInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetListenerMethod = GetMethodID(Env, CleverTapAPIClass, "setInAppNotificationButtonListener",
		"(Lcom/clevertap/android/sdk/InAppNotificationButtonListener;)V");
	if (!SetListenerMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, SetListenerMethod, ListenerInstance);
	HandleException(Env, "setInAppNotificationButtonListener()");
}

void DiscardInAppNotifications(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID DiscardMethod = GetMethodID(Env, CleverTapAPIClass, "discardInAppNotifications", "()V");
	if (!DiscardMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, DiscardMethod);
	HandleException(Env, "discardInAppNotifications()");
}

void ResumeInAppNotifications(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID ResumeMethod = GetMethodID(Env, CleverTapAPIClass, "resumeInAppNotifications", "()V");
	if (!ResumeMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, ResumeMethod);
	HandleException(Env, "resumeInAppNotifications()");
}

void SuspendInAppNotifications(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SuspendMethod = GetMethodID(Env, CleverTapAPIClass, "suspendInAppNotifications", "()V");
	if (!SuspendMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, SuspendMethod);
	HandleException(Env, "suspendInAppNotifications()");
}

FString GetCleverTapID(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID GetIDMethod = GetMethodID(Env, CleverTapAPIClass, "getCleverTapID", "()Ljava/lang/String;");
	if (!GetIDMethod)
	{
		return TEXT("");
	}

	// Call getCleverTapID() and retrieve a Java string
	jstring JavaID = (jstring)Env->CallObjectMethod(CleverTapInstance, GetIDMethod);
	if (HandleExceptionOrError(Env, !JavaID, TEXT("getCleverTapID failed")))
	{
		return TEXT("");
	}

	// Convert Java string to Unreal FString
	const char* IDChars = Env->GetStringUTFChars(JavaID, nullptr);
	FString CleverTapID = FString(IDChars);
	Env->ReleaseStringUTFChars(JavaID, IDChars);
	Env->DeleteLocalRef(JavaID);

	return CleverTapID;
}

void OnUserLogin(JNIEnv* Env, jobject CleverTapInstance, jobject Profile)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID OnUserLoginMethod = GetMethodID(Env, CleverTapAPIClass, "onUserLogin", "(Ljava/util/Map;)V");
	if (!OnUserLoginMethod)
	{
		return;
	}

	// Call onUserLogin with the given profile
	Env->CallVoidMethod(CleverTapInstance, OnUserLoginMethod, Profile);
	if (HandleException(Env, TEXT("onUserLogin() failed")))
	{
		return;
	}
}

void OnUserLogin(JNIEnv* Env, jobject CleverTapInstance, jobject Profile, const FString& CleverTapID)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID OnUserLoginMethod =
		GetMethodID(Env, CleverTapAPIClass, "onUserLogin", "(Ljava/util/Map;Ljava/lang/String;)V");
	if (!OnUserLoginMethod)
	{
		return;
	}

	// Convert FString to jstring for CleverTapID
	jstring jCleverTapId = Env->NewStringUTF(TCHAR_TO_UTF8(*CleverTapID));
	if (HandleExceptionOrError(Env, !jCleverTapId, TEXT("Failed to convert CleverTapID to jstring")))
	{
		return;
	}

	// Call onUserLogin with profile and CleverTapID
	Env->CallVoidMethod(CleverTapInstance, OnUserLoginMethod, Profile, jCleverTapId);
	if (HandleException(Env, TEXT("onUserLogin(Profile, CleverTapID)")))
	{
		// fall through
	}

	// Clean up JNI references
	Env->DeleteLocalRef(jCleverTapId);
}

void PushProfile(JNIEnv* Env, jobject CleverTapInstance, jobject Profile)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PushProfileMethod = GetMethodID(Env, CleverTapAPIClass, "pushProfile", "(Ljava/util/Map;)V");
	if (!PushProfileMethod)
	{
		return;
	}

	// Call pushProfile with the given profile
	Env->CallVoidMethod(CleverTapInstance, PushProfileMethod, Profile);
	if (HandleException(Env, "pushProfile()"))
	{
		// already logged; fall through
	}
}

void PushEvent(JNIEnv* Env, jobject CleverTapInstance, const FString& EventName)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PushEventMethod = GetMethodID(Env, CleverTapAPIClass, "pushEvent", "(Ljava/lang/String;)V");
	if (!PushEventMethod)
	{
		return;
	}

	// convert the eventName
	jstring JavaEventName = Env->NewStringUTF(TCHAR_TO_UTF8(*EventName));

	// Call pushEvent
	Env->CallVoidMethod(CleverTapInstance, PushEventMethod, JavaEventName);
	if (HandleException(Env, "pushEvent()"))
	{
		// already logged; fall through
	}
	Env->DeleteLocalRef(JavaEventName);
}

void PushEvent(JNIEnv* Env, jobject CleverTapInstance, const FString& EventName, jobject Actions)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PushEventMethod =
		GetMethodID(Env, CleverTapAPIClass, "pushEvent", "(Ljava/lang/String;Ljava/util/Map;)V");
	if (!PushEventMethod)
	{
		return;
	}

	// convert the eventName
	jstring JavaEventName = Env->NewStringUTF(TCHAR_TO_UTF8(*EventName));

	// Call pushEvent
	Env->CallVoidMethod(CleverTapInstance, PushEventMethod, JavaEventName, Actions);
	if (HandleException(Env, "pushEvent(EventName,Actions"))
	{
		// already logged; fall through
	}

	Env->DeleteLocalRef(JavaEventName);
}

void PushChargedEvent(JNIEnv* Env, jobject CleverTapInstance, jobject ChargeDetails, jobject Items)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PushChargedEventMethod =
		GetMethodID(Env, CleverTapAPIClass, "pushChargedEvent", "(Ljava/util/HashMap;Ljava/util/ArrayList;)V");
	if (!PushChargedEventMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, PushChargedEventMethod, ChargeDetails, Items);
	if (HandleException(Env, "pushChargedEvent()"))
	{
		// already logged; fall through
	}
}

jobject GetProperty(JNIEnv* Env, jobject CleverTapInstance, const FString& Key)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID GetPropertyMethod =
		GetMethodID(Env, CleverTapAPIClass, "getProperty", "(Ljava/lang/String;)Ljava/lang/Object;");
	if (!GetPropertyMethod)
	{
		return nullptr;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jobject JavaValue = Env->CallObjectMethod(CleverTapInstance, GetPropertyMethod, JavaKey);
	if (HandleException(Env, "getProperty()"))
	{
		// already logged; fall through
	}
	Env->DeleteLocalRef(JavaKey);

	return JavaValue;
}

static void DecrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, jobject Amount)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID DecrementMethod =
		GetMethodID(Env, CleverTapAPIClass, "decrementValue", "(Ljava/lang/String;Ljava/lang/Number;)V");
	if (!DecrementMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	Env->CallVoidMethod(CleverTapInstance, DecrementMethod, JavaKey, Amount);
	if (!HandleException(Env, "decrementValue()"))
	{
		// fall through
	}
	Env->DeleteLocalRef(JavaKey);
}

void DecrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, int Amount)
{
	static jclass IntegerClass = CacheClass(Env, "java/lang/Integer");
	static jmethodID IntegerCtor = GetMethodID(Env, IntegerClass, "<init>", "(I)V");
	if (!IntegerCtor)
	{
		return;
	}
	jobject NumberObj = Env->NewObject(IntegerClass, IntegerCtor, Amount);
	if (!HandleExceptionOrError(Env, !NumberObj, "Constructing Integer"))
	{
		return;
	}
	DecrementValue(Env, CleverTapInstance, Key, NumberObj);
	Env->DeleteLocalRef(NumberObj);
}

void DecrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, double Amount)
{
	static jclass DoubleClass = CacheClass(Env, "java/lang/Double");
	static jmethodID DoubleCtor = GetMethodID(Env, DoubleClass, "<init>", "(D)V");
	if (!DoubleCtor)
	{
		return;
	}
	jobject NumberObj = Env->NewObject(DoubleClass, DoubleCtor, Amount);
	if (!HandleExceptionOrError(Env, !NumberObj, "Constructing Double"))
	{
		return;
	}
	DecrementValue(Env, CleverTapInstance, Key, NumberObj);
	Env->DeleteLocalRef(NumberObj);
}

static void IncrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, jobject Amount)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID IncrementMethod =
		GetMethodID(Env, CleverTapAPIClass, "incrementValue", "(Ljava/lang/String;Ljava/lang/Number;)V");
	if (!IncrementMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	Env->CallVoidMethod(CleverTapInstance, IncrementMethod, JavaKey, Amount);
	if (!HandleException(Env, "incrementValue()"))
	{
		// fall through
	}
	Env->DeleteLocalRef(JavaKey);
}

void IncrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, int Amount)
{
	static jclass IntegerClass = CacheClass(Env, "java/lang/Integer");
	static jmethodID IntegerCtor = GetMethodID(Env, IntegerClass, "<init>", "(I)V");
	if (!IntegerCtor)
	{
		return;
	}
	jobject NumberObj = Env->NewObject(IntegerClass, IntegerCtor, Amount);
	if (!HandleExceptionOrError(Env, !NumberObj, "Constructing Integer"))
	{
		return;
	}
	IncrementValue(Env, CleverTapInstance, Key, NumberObj);
	Env->DeleteLocalRef(NumberObj);
}

void IncrementValue(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, double Amount)
{
	static jclass DoubleClass = CacheClass(Env, "java/lang/Double");
	static jmethodID DoubleCtor = GetMethodID(Env, DoubleClass, "<init>", "(D)V");
	if (!DoubleCtor)
	{
		return;
	}
	jobject NumberObj = Env->NewObject(DoubleClass, DoubleCtor, Amount);
	if (!HandleExceptionOrError(Env, !NumberObj, "Constructing Double"))
	{
		return;
	}
	IncrementValue(Env, CleverTapInstance, Key, NumberObj);
	Env->DeleteLocalRef(NumberObj);
}

void AddMultiValueForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, const FString& Value)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID AddMultiValueMethod =
		GetMethodID(Env, CleverTapAPIClass, "addMultiValueForKey", "(Ljava/lang/String;Ljava/lang/String;)V");
	if (!AddMultiValueMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jstring JavaValue = Env->NewStringUTF(TCHAR_TO_UTF8(*Value));
	Env->CallVoidMethod(CleverTapInstance, AddMultiValueMethod, JavaKey, JavaValue);
	HandleException(Env, "addMultiValueForKey()");
	Env->DeleteLocalRef(JavaKey);
	Env->DeleteLocalRef(JavaValue);
}

void AddMultiValuesForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, const TArray<FString>& Values)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID AddMultiValuesMethod =
		GetMethodID(Env, CleverTapAPIClass, "addMultiValuesForKey", "(Ljava/lang/String;Ljava/util/ArrayList;)V");
	if (!AddMultiValuesMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jobject JavaValues = StringArrayToJavaArrayList(Env, Values);
	Env->CallVoidMethod(CleverTapInstance, AddMultiValuesMethod, JavaKey, JavaValues);
	HandleException(Env, "addMultiValuesForKey()");
	Env->DeleteLocalRef(JavaKey);
	Env->DeleteLocalRef(JavaValues);
}

void RemoveMultiValueForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, const FString& Value)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID RemoveMultiValueMethod =
		GetMethodID(Env, CleverTapAPIClass, "removeMultiValueForKey", "(Ljava/lang/String;Ljava/lang/String;)V");
	if (!RemoveMultiValueMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jstring JavaValue = Env->NewStringUTF(TCHAR_TO_UTF8(*Value));
	Env->CallVoidMethod(CleverTapInstance, RemoveMultiValueMethod, JavaKey, JavaValue);
	HandleException(Env, "removeMultiValueForKey()");
	Env->DeleteLocalRef(JavaKey);
	Env->DeleteLocalRef(JavaValue);
}

void RemoveMultiValuesForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, const TArray<FString>& Values)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID RemoveMultiValuesMethod =
		GetMethodID(Env, CleverTapAPIClass, "removeMultiValuesForKey", "(Ljava/lang/String;Ljava/util/ArrayList;)V");
	if (!RemoveMultiValuesMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jobject JavaValues = StringArrayToJavaArrayList(Env, Values);
	Env->CallVoidMethod(CleverTapInstance, RemoveMultiValuesMethod, JavaKey, JavaValues);
	HandleException(Env, "removeMultiValuesForKey()");
	Env->DeleteLocalRef(JavaKey);
	Env->DeleteLocalRef(JavaValues);
}

void RemoveValueForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID RemoveValueMethod =
		GetMethodID(Env, CleverTapAPIClass, "removeValueForKey", "(Ljava/lang/String;)V");
	if (!RemoveValueMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	Env->CallVoidMethod(CleverTapInstance, RemoveValueMethod, JavaKey);
	HandleException(Env, "removeMultiValueForKey()");
	Env->DeleteLocalRef(JavaKey);
}

void SetMultiValuesForKey(JNIEnv* Env, jobject CleverTapInstance, const FString& Key, const TArray<FString> Values)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetMultiValuesMethod =
		GetMethodID(Env, CleverTapAPIClass, "setMultiValuesForKey", "(Ljava/lang/String;Ljava/util/ArrayList;)V");
	if (!SetMultiValuesMethod)
	{
		return;
	}

	jstring JavaKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Key));
	jobject JavaValues = StringArrayToJavaArrayList(Env, Values);
	Env->CallVoidMethod(CleverTapInstance, SetMultiValuesMethod, JavaKey, JavaValues);
	HandleException(Env, "setMultiValuesForKey()");
	Env->DeleteLocalRef(JavaKey);
	Env->DeleteLocalRef(JavaValues);
}

bool IsPushPermissionGranted(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID IsGrantedMethod = GetMethodID(Env, CleverTapAPIClass, "isPushPermissionGranted", "()Z");
	if (!IsGrantedMethod)
	{
		return false;
	}

	bool bGranted = Env->CallBooleanMethod(CleverTapInstance, IsGrantedMethod);
	if (HandleException(Env, "isPushPermissionGranted()"))
	{
		bGranted = false;
	}
	return bGranted;
}

void PromptForPushPermission(JNIEnv* Env, jobject CleverTapInstance, bool bFallbackToSettings)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PromptMethod = GetMethodID(Env, CleverTapAPIClass, "promptForPushPermission", "(Z)V");
	if (!PromptMethod)
	{
		return;
	}

	Env->CallVoidMethod(CleverTapInstance, PromptMethod, bFallbackToSettings);
	if (HandleException(Env, "promptForPushPermission()"))
	{
		// fall through
	}
}

jobject CreatePushPrimerConfigJSON(JNIEnv* Env, const FCleverTapPushPrimerAlertConfig& PrimerConfig)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID BuildMethod =
		GetStaticMethodID(Env, BridgeClass, "buildPushPrimerAlertConfig", "(Ljava/util/Map;)Lorg/json/JSONObject;");
	if (!BuildMethod)
	{
		return nullptr;
	}

	FCleverTapProperties ConfigProperties;
	ConfigProperties.Map.Add(TEXT("TitleText"), PrimerConfig.TitleText.ToString());
	ConfigProperties.Map.Add(TEXT("MessageText"), PrimerConfig.MessageText.ToString());
	ConfigProperties.Map.Add(TEXT("PositiveButtonText"), PrimerConfig.PositiveButtonText.ToString());
	ConfigProperties.Map.Add(TEXT("NegativeButtonText"), PrimerConfig.NegativeButtonText.ToString());
	ConfigProperties.Map.Add(TEXT("FollowDeviceOrientation"), PrimerConfig.bFollowDeviceOrientation);
	ConfigProperties.Map.Add(TEXT("FallbackToSettings"), PrimerConfig.bFallbackToSettings);
	jobject JavaMap = ConvertCleverTapPropertiesToJavaMap(Env, ConfigProperties);
	if (!JavaMap)
	{
		return nullptr;
	}

	jobject ResultJson = Env->CallStaticObjectMethod(BridgeClass, BuildMethod, JavaMap);
	if (HandleExceptionOrError(Env, !ResultJson, "buildPushPrimerAlertConfig()"))
	{
		ResultJson = nullptr;
	}
	Env->DeleteLocalRef(JavaMap);

	return ResultJson;
}

jobject CreatePushPrimerConfigJSON(JNIEnv* Env, const FCleverTapPushPrimerHalfInterstitialConfig& PrimerConfig)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID BuildMethod = GetStaticMethodID(
		Env, BridgeClass, "buildPushPrimerHalfInterstitialConfig", "(Ljava/util/Map;)Lorg/json/JSONObject;");
	if (!BuildMethod)
	{
		return nullptr;
	}

	FCleverTapProperties ConfigProperties;
	ConfigProperties.Map.Add(TEXT("TitleText"), PrimerConfig.TitleText.ToString());
	ConfigProperties.Map.Add(TEXT("MessageText"), PrimerConfig.MessageText.ToString());
	ConfigProperties.Map.Add(TEXT("PositiveButtonText"), PrimerConfig.PositiveButtonText.ToString());
	ConfigProperties.Map.Add(TEXT("NegativeButtonText"), PrimerConfig.NegativeButtonText.ToString());
	ConfigProperties.Map.Add(TEXT("FollowDeviceOrientation"), PrimerConfig.bFollowDeviceOrientation);
	ConfigProperties.Map.Add(TEXT("FallbackToSettings"), PrimerConfig.bFallbackToSettings);
	if (PrimerConfig.ImageURL.IsEmpty() == false)
	{
		ConfigProperties.Map.Add(TEXT("ImageURL"), PrimerConfig.ImageURL);
	}
	ConfigProperties.Map.Add(TEXT("BackgroundColor"), ColorToHexString(PrimerConfig.BackgroundColor));
	ConfigProperties.Map.Add(TEXT("ButtonBorderColor"), ColorToHexString(PrimerConfig.ButtonBorderColor));
	ConfigProperties.Map.Add(TEXT("TitleTextColor"), ColorToHexString(PrimerConfig.TitleTextColor));
	ConfigProperties.Map.Add(TEXT("MessageTextColor"), ColorToHexString(PrimerConfig.MessageTextColor));
	ConfigProperties.Map.Add(TEXT("ButtonTextColor"), ColorToHexString(PrimerConfig.ButtonTextColor));
	ConfigProperties.Map.Add(TEXT("ButtonBackgroundColor"), ColorToHexString(PrimerConfig.ButtonBackgroundColor));
	ConfigProperties.Map.Add(TEXT("ButtonBorderRadius"), PrimerConfig.ButtonBorderRadius);

	jobject JavaMap = ConvertCleverTapPropertiesToJavaMap(Env, ConfigProperties);
	if (!JavaMap)
	{
		return nullptr;
	}

	jobject ResultJson = Env->CallStaticObjectMethod(BridgeClass, BuildMethod, JavaMap);
	if (HandleExceptionOrError(Env, !ResultJson, "buildPushPrimerHalfInterstitialConfig()"))
	{
		ResultJson = nullptr;
	}

	Env->DeleteLocalRef(JavaMap);

	return ResultJson;
}

void PromptPushPrimer(JNIEnv* Env, jobject CleverTapInstance, jobject PrimerConfigJSON)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID PromptMethod = GetMethodID(Env, CleverTapAPIClass, "promptPushPrimer", "(Lorg/json/JSONObject;)V");
	if (!PromptMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, PromptMethod, PrimerConfigJSON);
	if (HandleException(Env, "promptPushPrimer()"))
	{
		// fall through
	}
}

void Unmute(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID Method = GetMethodID(Env, CleverTapAPIClass, "unmute", "()V");
	if (!Method)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, Method);
	HandleException(Env, "unmute()");
}

void DismissPipInApp(JNIEnv* Env, jobject CleverTapInstance)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID Method = GetMethodID(Env, CleverTapAPIClass, "dismissPipInApp", "()V");
	if (!Method)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, Method);
	HandleException(Env, "dismissPipInApp()");
}

void SetOffline(JNIEnv* Env, jobject CleverTapInstance, bool bIsOffline)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetMethod = GetMethodID(Env, CleverTapAPIClass, "setOffline", "(Z)V");
	if (!SetMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, SetMethod, bIsOffline);
	HandleException(Env, "setOffline()");
}

void SetOptOut(JNIEnv* Env, jobject CleverTapInstance, bool bIsOptingOut)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetMethod = GetMethodID(Env, CleverTapAPIClass, "setOptOut", "(Z)V");
	if (!SetMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, SetMethod, bIsOptingOut);
	HandleException(Env, "setOptOut()");
}

void EnableDeviceNetworkInfoReporting(JNIEnv* Env, jobject CleverTapInstance, bool bEnableCollection)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	static jmethodID SetMethod = GetMethodID(Env, CleverTapAPIClass, "enableDeviceNetworkInfoReporting", "(Z)V");
	if (!SetMethod)
	{
		return;
	}
	Env->CallVoidMethod(CleverTapInstance, SetMethod, bEnableCollection);
	HandleException(Env, "enableDeviceNetworkInfoReporting()");
}

void SetLocale(JNIEnv* Env, jobject CleverTapInstance, const FString& Locale)
{
	static jclass CleverTapAPIClass = GetCleverTapAPIClass(Env);
	// SDK 8.4.1+ takes a String (not java.util.Locale) and stores it in memory via DeviceInfo.setCustomLocale
	// (not persisted, so callers must set it again on every launch).
	static jmethodID SetMethod = GetMethodID(Env, CleverTapAPIClass, "setLocale", "(Ljava/lang/String;)V");
	if (!SetMethod)
	{
		return;
	}
	jstring JavaLocale = Env->NewStringUTF(TCHAR_TO_UTF8(*Locale));
	Env->CallVoidMethod(CleverTapInstance, SetMethod, JavaLocale);
	HandleException(Env, "setLocale()");
	Env->DeleteLocalRef(JavaLocale);
}

void EnableIntentNotifications(JNIEnv* Env)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID EnableMethod = GetStaticMethodID(Env, BridgeClass, "enableIntentNotifications", "()V");
	if (!EnableMethod)
	{
		return;
	}

	Env->CallStaticVoidMethod(BridgeClass, EnableMethod);
	HandleException(Env, "enableIntentNotifications()");
}

// Product Experiences (Variables)

void DefineStringVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, const FString& DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineStringVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;Ljava/lang/String;)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jstring JDefault = Env->NewStringUTF(TCHAR_TO_UTF8(*DefaultValue));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, JDefault);
	HandleException(Env, TEXT("defineStringVariable()"));
	Env->DeleteLocalRef(JName);
	Env->DeleteLocalRef(JDefault);
}

void DefineIntVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, int32 DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineIntVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;I)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, (jint)DefaultValue);
	HandleException(Env, TEXT("defineIntVariable()"));
	Env->DeleteLocalRef(JName);
}

void DefineInt64Variable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, int64 DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineInt64Variable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;J)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, (jlong)DefaultValue);
	HandleException(Env, TEXT("defineInt64Variable()"));
	Env->DeleteLocalRef(JName);
}

void DefineFloatVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, float DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineFloatVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;D)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, (jdouble)DefaultValue);
	HandleException(Env, TEXT("defineFloatVariable()"));
	Env->DeleteLocalRef(JName);
}

void DefineDoubleVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, double DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineDoubleVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;D)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, (jdouble)DefaultValue);
	HandleException(Env, TEXT("defineDoubleVariable()"));
	Env->DeleteLocalRef(JName);
}

void DefineBoolVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, bool DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineBoolVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;Z)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, (jboolean)DefaultValue);
	HandleException(Env, TEXT("defineBoolVariable()"));
	Env->DeleteLocalRef(JName);
}

void DefineStringMapVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, const TMap<FString, FString>& DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineStringMapVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;Ljava/util/Map;)V");
	if (!Method) return;

	// Build a java.util.HashMap<String,String>
	static jclass HashMapClass = CacheClass(Env, "java/util/HashMap");
	static jmethodID HashMapCtor = Env->GetMethodID(HashMapClass, "<init>", "(I)V");
	static jmethodID PutMethod = Env->GetMethodID(HashMapClass, "put",
		"(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");

	jobject JMap = Env->NewObject(HashMapClass, HashMapCtor, (jint)DefaultValue.Num());
	for (const auto& Pair : DefaultValue)
	{
		jstring JKey = Env->NewStringUTF(TCHAR_TO_UTF8(*Pair.Key));
		jstring JVal = Env->NewStringUTF(TCHAR_TO_UTF8(*Pair.Value));
		Env->CallObjectMethod(JMap, PutMethod, JKey, JVal);
		Env->DeleteLocalRef(JKey);
		Env->DeleteLocalRef(JVal);
	}
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName, JMap);
	HandleException(Env, TEXT("defineStringMapVariable()"));
	Env->DeleteLocalRef(JName);
	Env->DeleteLocalRef(JMap);
}

void DefineFileVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "defineFileVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;)V");
	if (!Method) return;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, JName);
	HandleException(Env, TEXT("defineFileVariable()"));
	Env->DeleteLocalRef(JName);
}

void FetchVariables(JNIEnv* Env, jobject CleverTapInstance, jlong NativeInstancePtr)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "fetchVariables",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;J)V");
	if (!Method) return;
	Env->CallStaticVoidMethod(BridgeClass, Method, CleverTapInstance, NativeInstancePtr);
	HandleException(Env, TEXT("fetchVariables()"));
}

void SyncVariables(JNIEnv* Env, jobject CleverTapInstance)
{
	static jmethodID Method = Env->GetMethodID(GetCleverTapAPIClass(Env), "syncVariables", "()V");
	if (!Method) return;
	Env->CallVoidMethod(CleverTapInstance, Method);
	HandleException(Env, TEXT("syncVariables()"));
}

FString GetStringVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, const FString& DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getStringVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jstring JDefault = Env->NewStringUTF(TCHAR_TO_UTF8(*DefaultValue));
	jstring JResult = (jstring)Env->CallStaticObjectMethod(BridgeClass, Method, CleverTapInstance, JName, JDefault);
	Env->DeleteLocalRef(JName);
	Env->DeleteLocalRef(JDefault);
	if (HandleExceptionOrError(Env, !JResult, TEXT("getStringVariable failed"))) return DefaultValue;
	const char* ResultChars = Env->GetStringUTFChars(JResult, nullptr);
	FString Result = FString(ResultChars);
	Env->ReleaseStringUTFChars(JResult, ResultChars);
	Env->DeleteLocalRef(JResult);
	return Result;
}

int32 GetIntVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, int32 DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getIntVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;I)I");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jint Result = Env->CallStaticIntMethod(BridgeClass, Method, CleverTapInstance, JName, (jint)DefaultValue);
	Env->DeleteLocalRef(JName);
	if (HandleException(Env, TEXT("getIntVariable()"))) return DefaultValue;
	return (int32)Result;
}

int64 GetInt64Variable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, int64 DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getInt64Variable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;J)J");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jlong Result = Env->CallStaticLongMethod(BridgeClass, Method, CleverTapInstance, JName, (jlong)DefaultValue);
	Env->DeleteLocalRef(JName);
	if (HandleException(Env, TEXT("getInt64Variable()"))) return DefaultValue;
	return (int64)Result;
}

float GetFloatVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, float DefaultValue)
{
	// Float variables are stored as Var<Double> in the Java SDK (no 32-bit float generic).
	// The C++ float is widened to jdouble here and narrowed back on return — this is the
	// documented precision trade-off (server value e.g. 67.3 may return as 67.300003f).
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getFloatVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;D)D");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jdouble Result = Env->CallStaticDoubleMethod(BridgeClass, Method, CleverTapInstance, JName, (jdouble)DefaultValue);
	Env->DeleteLocalRef(JName);
	if (HandleException(Env, TEXT("getFloatVariable()"))) return DefaultValue;
	return (float)Result;
}

double GetDoubleVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, double DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getDoubleVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;D)D");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jdouble Result = Env->CallStaticDoubleMethod(BridgeClass, Method, CleverTapInstance, JName, (jdouble)DefaultValue);
	Env->DeleteLocalRef(JName);
	if (HandleException(Env, TEXT("getDoubleVariable()"))) return DefaultValue;
	return (double)Result;
}

bool GetBoolVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, bool DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getBoolVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;Z)Z");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jboolean Result = Env->CallStaticBooleanMethod(BridgeClass, Method, CleverTapInstance, JName, (jboolean)DefaultValue);
	Env->DeleteLocalRef(JName);
	if (HandleException(Env, TEXT("getBoolVariable()"))) return DefaultValue;
	return (bool)Result;
}

TMap<FString, FString> GetStringMapVariable(JNIEnv* Env, jobject CleverTapInstance, const FString& Name, const TMap<FString, FString>& DefaultValue)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getStringMapVariable",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;)Ljava/util/Map;");
	if (!Method) return DefaultValue;
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jobject JResult = Env->CallStaticObjectMethod(BridgeClass, Method, CleverTapInstance, JName);
	Env->DeleteLocalRef(JName);
	if (HandleExceptionOrError(Env, !JResult, TEXT("getStringMapVariable failed"))) return DefaultValue;

	// Convert java Map<String,String> -> TMap<FString,FString>
	static jclass MapClass = CacheClass(Env, "java/util/Map");
	static jmethodID EntrySetMethod = Env->GetMethodID(MapClass, "entrySet", "()Ljava/util/Set;");
	static jclass SetClass = CacheClass(Env, "java/util/Set");
	static jmethodID IteratorMethod = Env->GetMethodID(SetClass, "iterator", "()Ljava/util/Iterator;");
	static jclass IteratorClass = CacheClass(Env, "java/util/Iterator");
	static jmethodID HasNextMethod = Env->GetMethodID(IteratorClass, "hasNext", "()Z");
	static jmethodID NextMethod = Env->GetMethodID(IteratorClass, "next", "()Ljava/lang/Object;");
	static jclass EntryClass = CacheClass(Env, "java/util/Map$Entry");
	static jmethodID GetKeyMethod = Env->GetMethodID(EntryClass, "getKey", "()Ljava/lang/Object;");
	static jmethodID GetValueMethod = Env->GetMethodID(EntryClass, "getValue", "()Ljava/lang/Object;");

	TMap<FString, FString> Result;
	jobject EntrySet = Env->CallObjectMethod(JResult, EntrySetMethod);
	if (HandleExceptionOrError(Env, !EntrySet, TEXT("getStringMapVariable.entrySet()")))
	{
		Env->DeleteLocalRef(JResult);
		return DefaultValue;
	}
	jobject Iterator = Env->CallObjectMethod(EntrySet, IteratorMethod);
	if (HandleExceptionOrError(Env, !Iterator, TEXT("getStringMapVariable.iterator()")))
	{
		Env->DeleteLocalRef(EntrySet);
		Env->DeleteLocalRef(JResult);
		return DefaultValue;
	}
	while (Env->CallBooleanMethod(Iterator, HasNextMethod))
	{
		jobject Entry = Env->CallObjectMethod(Iterator, NextMethod);
		jstring JKey = (jstring)Env->CallObjectMethod(Entry, GetKeyMethod);
		jstring JVal = (jstring)Env->CallObjectMethod(Entry, GetValueMethod);
		if (JKey && JVal)
		{
			const char* KeyChars = Env->GetStringUTFChars(JKey, nullptr);
			const char* ValChars = Env->GetStringUTFChars(JVal, nullptr);
			Result.Add(FString(KeyChars), FString(ValChars));
			Env->ReleaseStringUTFChars(JKey, KeyChars);
			Env->ReleaseStringUTFChars(JVal, ValChars);
		}
		if (JKey) Env->DeleteLocalRef(JKey);
		if (JVal) Env->DeleteLocalRef(JVal);
		Env->DeleteLocalRef(Entry);
	}
	Env->DeleteLocalRef(Iterator);
	Env->DeleteLocalRef(EntrySet);
	Env->DeleteLocalRef(JResult);
	return Result;
}

FString GetFileVariablePath(JNIEnv* Env, jobject CleverTapInstance, const FString& Name)
{
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getFileVariablePath",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;Ljava/lang/String;)Ljava/lang/String;");
	if (!Method) return TEXT("");
	jstring JName = Env->NewStringUTF(TCHAR_TO_UTF8(*Name));
	jstring JResult = (jstring)Env->CallStaticObjectMethod(BridgeClass, Method, CleverTapInstance, JName);
	Env->DeleteLocalRef(JName);
	if (HandleExceptionOrError(Env, !JResult, TEXT("getFileVariablePath failed"))) return TEXT("");
	const char* ResultChars = Env->GetStringUTFChars(JResult, nullptr);
	FString Result = FString(ResultChars);
	Env->ReleaseStringUTFChars(JResult, ResultChars);
	Env->DeleteLocalRef(JResult);
	return Result;
}

TArray<TMap<FString, FString>> GetVariants(JNIEnv* Env, jobject CleverTapInstance)
{
	TArray<TMap<FString, FString>> Result;
	static jclass BridgeClass = GetBridgeClass(Env);
	static jmethodID Method = GetStaticMethodID(Env, BridgeClass, "getVariants",
		"(Lcom/clevertap/android/sdk/CleverTapAPI;)Ljava/lang/String;");
	if (!Method) return Result;

	jstring JJson = (jstring)Env->CallStaticObjectMethod(BridgeClass, Method, CleverTapInstance);
	if (HandleExceptionOrError(Env, !JJson, TEXT("getVariants failed"))) return Result;

	const char* JsonChars = Env->GetStringUTFChars(JJson, nullptr);
	FString JsonString = FString(JsonChars);
	Env->ReleaseStringUTFChars(JJson, JsonChars);
	Env->DeleteLocalRef(JJson);

	TArray<TSharedPtr<FJsonValue>> JsonArray;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
	if (!FJsonSerializer::Deserialize(Reader, JsonArray)) return Result;

	for (const TSharedPtr<FJsonValue>& Element : JsonArray)
	{
		const TSharedPtr<FJsonObject>* ObjPtr;
		if (!Element->TryGetObject(ObjPtr)) continue;
		TMap<FString, FString> Entry;
		for (const auto& KV : (*ObjPtr)->Values)
		{
			FString StrVal;
			if (!KV.Value->TryGetString(StrVal))
				StrVal = KV.Value->AsString();
			Entry.Add(KV.Key, StrVal);
		}
		Result.Add(Entry);
	}
	return Result;
}

}}} // namespace CleverTapSDK::Android::JNI
